# COMPEL: 
Make people do what you want via threats, lies, flattery or reasoned argument.

# DELVE: 
Progress into dangerous or unknown territory.

# DISCERN: 
Understand the world by drawing on accessible information.

# ENDURE: 
Resist the effects of the Heart on your body and mind.

# EVADE: 
Get away from someone or something that’s trying to track you down.

# HUNT: 
Track down someone or something that’s trying to get away from you.

# KILL: 
End the lives of people and things with weapons or your bare hands.

# MEND: 
Repair something or someone that is broken; build something new.

# SNEAK: 
Hide yourself or things from the attention of others.