# CURSED: 
Actively harmful locations. Places touched by the Heart.

# DESOLATE:
Wastelands and abandoned towns.

# HAVEN:
Settlements where people live, work and form communities.

# OCCULT: 
Hidden knowledge and black magic.

# RELIGION: 
Gods, and things worshipped like gods.

# TECHNOLOGY: 
Machines, buildings and devices

# WARREN: 
Cramped, dense corridors.

# WILD: 
Wilderness, vegetation and animals.