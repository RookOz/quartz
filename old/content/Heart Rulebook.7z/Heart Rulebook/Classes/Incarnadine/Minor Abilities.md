# A RED AND BLOODY BUSINESS
You are well versed in the oldest transaction in the world – blood for blood. Gain the Kill skill. If you’re killing someone or something that’s shed your blood before, your attack gains the [[Tags#BRUTAL|BRUTAL tag]].

# AN EYE FOR THE STRANGE
Years of exposure to unnatural energies from the items you’ve bought and sold has left a dirty handprint on your soul. Gain the Occult domain. Once per session, you may exchange one domain on one resource for any other.

# BETTER SAFE THAN SORRY
Gain +1 Protection in the Mind, Echo, Supplies or Fortune resistance. You can take this advance more than once.

# CREATIVE ACQUISITIONS
You know that the best price for any item is free. Gain the Sneak skill. When you attempt to steal a resource or equipment of D10 value or higher, roll with mastery.

# CREATIVE BOOK-KEEPING
A flexible grasp on reality means you have something for every occasion on hand. Gain +2 Supplies Protection.

# EYES IN THE BACK OF YOUR HEAD
You’ve set up enough crooked deals to know when you’re about to be suckered into one. Gain the Discern skill. When you stand still and concentrate, you can quite literally see behind you as though you had eyes in the back of your head. Doing this for too long causes headaches and nausea.

# JACK OF ALL TRADES
Gain access to one of the following skills: Compel, Discern, Endure, Hunt, Kill, Mend, Sneak. You can take this advance more than once.

# LOST IT ALL
You understand – truly – the wretched sensation of having less than nothing. Gain the Desolate domain. Once per session ask the GM where the nearest source of wealth is and they will tell you.

# MAKE DO
Periods of poverty have taught you to make the best of what you’ve got and keep things ticking over until your next big score. Gain the Mend skill. Once per session, you can immediately fix something that’s broken – but it only works once. After that, it’s destroyed past the point of repair.

# ON THE RUN
You’ve been running from your creditors for years; you’re not above crawling through shit on your hands and knees to survive. Gain the Evade skill. Mark D4 stress to Supplies to shift the attention of a person or creature to another PC or an important NPC.

# PRIEST OF INCARNE
Most Incarnadines pay lip service to their god whilst paying off their debt; you’ve bought in wholesale, and you understand the terrible power of your patron. Gain the Religion domain. Once per session, when you visit a shrine of Incarne and preach to the faithful, refresh equal to the size of the shrine (D4 for cupboard-sized devotionals, D12 for a glorious temple).
The Red Market is too fractious and shifting to act as a shrine for the purposes of this ability.

# RED MARKETEER
For a while, you were bold enough to trade blood and souls in the shifting alleyways of the Red Market. Gain the Warren domain. If someone tries to take what’s yours, your attacks gain the [[Tags#BRUTAL|BRUTAL tag]] when you attempt to stop them.

# VALUABLE ASSET
Incarne won’t let you die, because then they can’t collect what they’re owed. Gain +2 Fortune Protection.

# AREAS OF OPPORTUNITY
Gain access to one of the following domains: Cursed, Desolate, Occult, Religion, Technology, Warren. You can take this advance more than once.