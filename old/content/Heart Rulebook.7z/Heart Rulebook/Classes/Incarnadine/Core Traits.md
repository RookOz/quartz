![[Incarnadine  Core Traits.png]]

[[Tags#RANGED|RANGED tag]]

[[Tags#EXPENSIVE|EXPENSIVE tag]]

[[Tags#TIRING|TIRING tag]]

[[Tags#SPREAD|SPREAD tag]]

[[Tags#ONE-SHOT|ONE-SHOT tag]]