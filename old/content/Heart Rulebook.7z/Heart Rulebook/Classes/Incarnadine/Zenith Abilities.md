# ULTIMATE CREDIT
A life lived in service of Incarne brings with it a powerful favour. Once, and only once, you can buy anything (except the Heart Itself). You own this physical, conceptual or immaterial thing and have as much control over it as you do a knife, a suit of clothes or anything else you own. Two sessions from now, the debt will be recalled, and it will take your life.

# ULTIMATE DEBT
You wield the wrath of Incarne. Once, and only once, you can unload the weight of Incarne’s debt upon a single luckless individual, location or entity (except the Heart Itself). Anything and everything that could go wrong for the target does go wrong, and it does so catastrophically, but they do not die. Once per situation, you can harvest the debt on the target to clear stress from your resistance tracks – when you do so, roll a D10. On a 2 or higher, remove that much stress. On a 1, your luck runs out, and a cosmic loophole sees Incarne claim your life.

# ULTIMATE REWARD
You did it – you paid it off. You finally got out of Incarne’s debt. You can retire to a normal life wherever you please and start a family, maybe set up a small business – whatever you want. You die several years from now, maybe decades, surroundedby your loved ones.