# ASCENSION
You transcend the need for mortal flesh. The Goddess appears before you in her trifold majesty: a scintillating blaze of divinity, silver-crimson and midnight black. She blesses you, and your frail mortal anatomy becomes a conduit for her eternal flesh.
You take on an angelic form. The descriptions of angels of the Moon Beneath are varied, but multiple heads, six or more wings, mighty voices raised in exaltation and an abundance of eyes are common themes.
In your new form, your many hyperdimensional claws and appendages inflict D10 damage and possess the [[Tags#PIERCING|PIERCING tag]]. You roll 6D10 when striking at those who would threaten the faithful or desecrate sacred ground, and all other actions automatically fail.
At the end of the situation, you are transfused into ossified bone-crystal, your radiance added to her incomprehensible refulgence, and retired as a player character.

# GLORY
You come face to face with the goddess herself, and the radiance reflected in your eyes is too much for people to behold. You keep your face covered. When you uncover it, all those who can see you are stunned and awed, unable to look upon you without falling to their knees. Those who remain in your presence miraculously remove one Minor Blood or Mind fallout result, or downgrade a Major to a Minor after about an hour. Most NPCs will convert to your faith on the spot.
In the City Above, a team of aelfir hunters working for the Solar Church are mobilised and dispatched to kill you. They will find and eliminate you, and you will die.

# TESTAMENT OF FAITH
You become a beacon of hope for those struck by fear or desperation. To activate this ability, die a martyr’s death. The ground on which you died (or where you’re buried, whichever is more dramatically appropriate) becomes holy to the church of the Moon Beneath. 
Over the next few months, pilgrims will visit the site and erect a suitable shrine. For the remainder of the campaign, and at the GM’s discretion any future campaigns, the shrine functions as a landmark with some appropriate haunts.
Once per campaign, when the surviving player characters visit it, they can beseech your spirit to answer a question. You will deliver valuable wisdom.