# BLESSED DEPRIVATION
In your darkest hour, She will bless you with her immaculate grace. Gain the Desolate domain. When you are suffering from ongoing Supplies fallout, gain the [[Tags#TRUSTY|TRUSTY tag]] when you roll to inflict stress on delves.

# GRAVE DUTY
You spent time amongst the dead in the sepulchres, and time amongst the living at the funerals. Gain the Warren domain. Once per session, when you console or bolster an ally in times of fear and uncertainty, they gain +1 Mind protection until the end of the session.

# THE GODDESS’ GIFTS
Gain access to one of the following skills: Compel, Discern, Endure, Evade, Hunt, Kill, Mend. You can take this advance more than once.

# THE LEFT HAND OF THE GODDESS
The faithful are a bountiful garden, and it is your task to excise disease and corruption at the root. Gain the Kill skill and +1 Blood Protection.

# LIAR’S BURDEN
The moon beneath does not tolerate the wicked words of sinners. Gain the Discern skill. If you suspect an NPC is lying to you, roll  Discern+Religion. On a success, if they were lying, they mark D4 stress; their mouth streams with blood as though they had attempted to chew on broken glass.

# INCANDESCENT COMMUNION
In the tear between worlds, She blessed you with nightblack eyes that resonate with Her Eternal Light. Gain the Cursed domain. You can see in total darkness as though the area was illuminated by candle-light.

# RIGHTEOUS RHETORIC
You have argued over the interpretation of scripture with the temple elders time and time again. Gain the Compel skill. When you invoke your holy texts in conversation with another member of your faith, roll with mastery.

# RITE OF PLACIDITY
Scholars who search for the Lady often find her immense majesty hard to bear, but you are well versed in the sacred canticles that allow you to weather her revelations. Gain +2 Mind Protection.

# SACRED TATTOO
You carry your holy text inked onto your skin, a litany of pain endured in the name of Her Cthonic Majesty. Gain +2 Fortune Protection.

# SHARD OF THE TEMPLE DOOR
The great doors of the Moon Ascendant temple were smashed to pieces on the night of the purge. You carry a shard of the door, reminding you that your faith is eternal. Gain the Endure skill. Once per session, when you touch the shard to a closed door, it will not open for at least an hour (unless it is destroyed).

# TOMES OF KNOWLEDGE
Gain access to one of the following domains: Cursed, Desolate, Haven, Religion, Technology, Wild, Warren. You can take this advance more than once.

# UNWAVERING FAITH
Gain +1 Protection in the Mind, Supplies, Blood or Fortune resistance. You can take this advance more than once.

# WORDS OF GRACE
As you shine Her light into dark places, you are filled with her glory. Gain the Haven domain. Once per session, when you lead the  community in an act of mercy and grace, refresh D6.