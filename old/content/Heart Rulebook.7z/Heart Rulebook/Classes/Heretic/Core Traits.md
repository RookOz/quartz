![[Heretic  Core Traits.png]]

[[Tags#OBSCURING|OBSCURING tag]]

[[Tags#DANGEROUS|DANGEROUS tag]]

[[Tags#RANGED|RANGED tag]]

[[Tags#RELOAD|RELOAD tag]]

[[Tags#BRUTAL|BRUTAL tag]]