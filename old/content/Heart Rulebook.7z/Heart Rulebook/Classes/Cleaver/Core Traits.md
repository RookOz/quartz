![[Cleaver Core Traits.png]]

[[Tags#BRUTAL|BRUTAL tag]]

[[Tags#TIRING|TIRING tag]]

[[Tags#RANGED|RANGED tag]]