# ANGELIC
You undergo the ultimate heartsblood transformation – you become an agent of the Heart Itself, a red and mighty angel, and your approach is ruin incarnate. Following a transformation process that is either distressingly sudden or agonisingly slow, your flesh and bones burst and reform into those of a towering Angel. You are as powerful and ruinous as any other Angel, but you retain your will – for the remainder of the current situation, at least. After that, you are absorbed back into the flesh of the Heart, and become another agent of unreality that will beset delvers in centuries to come.

# LEGENDARY BEAST
You shed what little remains of your human form and ascend into something many-limbed and majestic. When you gain access to this ability, you begin your hunt to slay the Beast: the capital-B Beast, an ancient creature wrought from stone and muscle and petrified wood. You will kill the Beast, and in doing so, you understand it perfectly.
You become the new Beast, an epitome of bestial power and a legendary terror in the City Beneath. You become part of the wilderness of the Heart; it grows around you more than ever, blossoming into patterns that you dream of in the echoing recesses of your ancient gestalt mind. Create a new landmark that you call your territory; here, you are lord and ruler, but you can no longer leave. One day, another Cleaver will find you, kill you and become you.

# WEALD AND WOE
Following the passing of a legendary hunter, sometimes the Forest – an ancient heaven for wordless hunters and the gigantic beasts they pursue – crashes into the Heart to claim their body as a prize.
To activate this ability, die. 
The landmark you are currently occupying is overwhelmed by the Forest. If you’re on a delve, immediately establish a new landmark where you’re standing. Relic trees crash and tear through the walls of reality, swarms of giant beasts smash apart the world around them and your body is subsumed into the black, fecund soil to be reborn. This fracture will remain connected to the landmark for a few hours before it is severed – then the trees will petrify into a dead forest of glittering opal, ill-auspiced and frequented only by the dead. 
When you are reborn, you awaken in the Forest. You have an afterlife of hunting, feasting and howling at the strange, indifferent stars to look forward to.
