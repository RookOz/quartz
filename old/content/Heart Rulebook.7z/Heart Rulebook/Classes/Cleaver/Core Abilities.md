# HEARTSBLOOD
You have a bone-deep connection to the Heart Itself; the closer you get, the more powerful you become. Your minimum protection value for all resistances is equal to the tier of the Heart you are currently on.
This value doesn’t add to other sources of protection, but your base protection can’t be lower than your current tier unless you specifically lose access to it due to fallout.

# THE RED FEAST
Your crucible guts pluck memories from the meat. 
When you eat a resource, you gain any domains associated with that resource until the end of the situation. If you already have access to the domain, gain an appropriate knack. There’s no limit to what you can eat, but tough or noxious materials might require an Endure+Cursed check to avoid causing yourself harm. Consuming resources requires your attention and leaves you exposed, so doing it successfully in stressful situations (such as combat) could require a Sneak or Evade roll.