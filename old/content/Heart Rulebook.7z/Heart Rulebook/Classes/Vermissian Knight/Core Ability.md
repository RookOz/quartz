# VERMISSIAN PLATE
Your armour is made up of scavenged, barely-understood technology from the alternate realities inside the Vermissian network. Once per session, when you consume a resource with the Technology or Occult domains by augmenting or repairing your armour, roll the resource’s dice and choose one of the following:
• Remove stress marked against Blood, Mind or Echo equal to the amount rolled.
• Inflict stress on a delve or adversary equal to the amount rolled.
• (D8 resource or higher) Gain access to a skill or domain for the rest of the session.
• (D8 resource or higher) Increase your Blood protection by 1 for the rest of the situation.