# ARCANE REBREATHER
You possess a gas mask that filters out airborne infectants from the Heart. +2 Echo Protection.

# ARMOUR PLATING
Retro-engineered from train carriages, this trademark chest armour still bears the symbols of the rail networks that built the Vermissian. +2 Blood Protection.

# BLACK KNIGHT
You have spent time studying the forbidden arts with the sages of your order. Gain the Occult domain. Once per session, when you enter a landmark, you can intuit the location of an occult sect who are hiding information that will aid you in your quest.

# KNIGHT PROTECTOR 
You are willing to kill and die to ensure that the Vermissian is safe. Gain the Kill skill. Once per situation, when an ally within arm’s reach would mark stress to Blood, you mark an equivalent amount to Blood instead.

# HELLWALKER
You have been anointed with the sacred oils that protect you from the nightmare energies of the Heart. Gain the Cursed domain. You can use a resource with the Cursed domain to activate your [[Heart Rulebook/Classes/Vermissian Knight/Core Ability|VERMISSIAN PLATE]] core ability.

# PHANTOM LENS
Various blood, ichors and spittles have been used to treat these lenses, allowing you to see into dimensions other than the material. Gain the Hunt skill. While you wear these lenses, you can track anything – even if it doesn’t leave a tangible trail.

# PROTECTOR’S GAUNTLET
A heavy metal gauntlet bearing the emblem of your house: The Lords Galvanic, The Free Wheels, The Cross Countrymen.
+1 Blood Protection, +1 Fortune protection.

# SANGUINARY ARRAY
Your inefficient mortal heart is supplemented by a rig that extracts, filters and nourishes your vital fluids. One side effect of this is that your blood acts as an antenna for the scattershot electrical impulses of the Heart. 
Gain the Discern skill. If one of your senses becomes damaged or unusable, you can replace it with the weird echoes that shudder through your exposed blood – it’s not perfect, but it’ll do.

# STALWART
Gain +1 Protection in the Blood, Echo, Supplies or Fortune resistance. You can take this advance more than once.

# STEELBONES
Your armour bolts onto special implants that absorb harmful energy and distribute it through your body. Gain the Endure skill. You can fall distances of up to 3 storeys without taking damage.

# STUDENT OF THE SAGES
Gain access to one of the following skills: Compel, Delve, Discern, Endure, Hunt, Kill, Mend. You can take this advance more than once.

# TUNNEL RAT
You have performed the Rite of Suffocation, and know ways of slowing your breathing to survive longer. Gain the Warren domain. You can hold your breath for a very long time, allowing you to stay underwater or in toxic areas for extended periods.

# WELL TRAVELLED
Gain access to one of the following domains: Cursed, Desolate, Haven, Occult, Technology, Wild, Warren. You can take this advance more than once.