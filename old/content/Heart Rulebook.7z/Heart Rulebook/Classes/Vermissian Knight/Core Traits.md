![[Vermissian Knight  Core Traits.png]]

[[Tags#BRUTAL|BRUTAL tag]]

[[Tags#LOUD|LOUD tag]]

[[Tags#TIRING|TIRING tag]]

[[Tags#BLOCK|BLOCK tag]]