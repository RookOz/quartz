# ADVANCED TRAINING
Gain access to one of the following skills: Compel, Delve, Discern, Endure, Evade, Hunt, Kill, Mend, Sneak. You can take this advance more than once.

# THE BETTER PART OF VALOUR
You’ll get everyone out alive, if not intact. Gain the Evade skill. If you succeed on an Evade roll, all nearby allies roll with mastery when trying to evade until you next act.

# CLOSE QUARTERS
You like things to be up-close and personal. Gain the Warren domain. When in areas with the Warren domain, gain +1 Blood protection.

# CUSTODIAN
You – and those who wore the badge before you – have spent so much time rebuilding shattered lives and shattered homes that everyone welcomes you. 
Gain the Mend skill. If you are in a populated location you can always find someone willing to take you in, give you somewhere to sleep and maybe even some warm food.

# ECHOES OF THE 33RD
Gain access to one of the following domains: Cursed, Desolate, Haven, Technology, Warren, Wild. You can take this advance more than once.

# HARD AS NAILS
Gain access to +1 Blood, Mind, Echo or Supplies Protection. You can take this advance more than once.

# KILL COUNT
Your weapons are cross-hatched with kill-marks; a testament to what you’ve done to protect others. Gain the Kill skill. Whenever you kill a person or creature, remove 1 stress from any resistance.

# LIQUID COURAGE
You have developed a drinking habit to stay sane, because the booze isn’t going to be what kills you.
+1 Mind Protection. When you go drinking to remove Mind stress or fallout, treat the resource you spend as one dice size higher.

# MARSHAL
You find out what’s wrong and do your level best to fix it; if you can get paid in the process, so much the better. Gain the Compel skill. Once per session, when you enter a landmark, you learn of an injustice, threat or danger that’s worrying the people there. Some folks might be able to pay you if you help them.

# OUR GLORIOUS LADY
You found the goddess at the bottom of a bottle; she turned your life around. Gain the Religion domain. Once per session, clear D4 Blood stress from an ally as you beseech the goddess for their protection.

# QUARTERMASTER TRAINING
You have studied under the Quartermasters of the Hounds, learning the valuable skill of creative acquisition.
+1 Supplies Protection. You don’t like to be unarmed – you steal, build and improvise what you need. Your “unarmed” attacks become (D6, Brutal, Unreliable); on a failure, it breaks and your unarmed attacks are D4 as standard.

# ROUND THE NEXT CORNER
You can find a place to shelter, smoke a roll-up and let things blow over. Gain the Delve skill. Once per delve, you find an out-of-the-way location where you can catch your breath and recuperate without fear of being discovered by your enemies. You can take your time and heal here without incurring a bane.

# SERGEANT
You wear the trademark heavy long-coat of a Sergeant of the Hounds, designed to mark you out as a protector of the people. +1 Blood  protection. Once per situation, when an adversary or NPC directs their attention towards an ally, declare that they pay attention to you instead.