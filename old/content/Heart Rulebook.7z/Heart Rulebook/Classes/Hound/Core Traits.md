![[Hound  Core Traits.png]]

[[Tags#RANGED|RANGED tag]]

[[Tags#PIERCING|PIERCING tag]]

[[Tags#EXPENSIVE|EXPENSIVE tag]]

[[Tags#BRUTAL|BRUTAL tag]]

[[Tags#RELOAD|RELOAD tag]]