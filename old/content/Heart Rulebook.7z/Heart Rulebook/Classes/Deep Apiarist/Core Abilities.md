# THE HIVE
The sweetlings nest within your body. Some of your organs are replaced with complex copies made from wax by industrious bees. They live within you – a few at first, but as you grow in power, great swarms. Their curious buzzing aligns your mind with the Hive.
At the beginning of each situation, clear all Mind stress as incipient madness flows through you and into the Hive. You can never benefit from Mind protection or remove stress from Mind, aside from using this ability.

# RELEASE THE SWARM
You send out a swarm of bees, eager to defend you. Gain access to the following weapon: (Kill D4, [[Tags#SPREAD|SPREAD tag]], [[Tags#RANGED|RANGED tag]]).