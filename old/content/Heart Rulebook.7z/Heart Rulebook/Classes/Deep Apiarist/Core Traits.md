![[Deep Apiarist  Core Traits.png]]

[[Tags#BRUTAL|BRUTAL tag]]

[[Tags#RELOAD|RELOAD tag]]

[[Tags#EXTREME RANGE|EXTREME RANGE tag]]

[[Tags#DEBILITATING|DEBILITATING tag]]

[[Tags#SMOKE|SMOKE tag]]