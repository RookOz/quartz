# ABSOLUTE STASIS
You use up every ounce of your power to encase a dangerous foe in crystal. To cast this spell, touch a creature; you and they are forever bound together, rendered perfect, inviolable and immobile in glittering, transparent crystal like a statue.
No-one has yet managed to break one of these statues. In fact, interacting with the crystal in any way incurs D10 stress as it spreads instantaneously from one body to another, binding another person into the curious tableau. It is believed that those inside the crystal are still alive and conscious, but as previously mentioned, no-one has managed to break one open to find out.

# DIMENSIONAL BASTION
You become a conduit to the Hive, and thousands of glyph-marked bees rush out of your body and clothing until your physical form is dissolved entirely into the swarm. The bees quickly spread out to the edges of the landmark you are occupying and ward it, building crystalline structures that keep the energies of the Heart at bay.
While the bees endure, this place will be safe from the uncaring and everchanging Heart Itself. You aren’t quite dead, but you definitely aren’t alive either: you persist as a message passed between the bees, an echo in the place. Rename the landmark appropriately.

# SURRENDER TO CHAOS
A lifetime of carving order from disorder, and still the Heart remains chaotic. You lost before you ever started. You give in, tragically and catastrophically. 
When you cast this spell, everything that is ordered around you flips to disorder: buildings collapse, machinery overloads and malfunctions, disease runs rampant, language breaks down and fire crackles at the edges of your vision. You are unmade, inverted; your bees are destroyed; and the Heart arrives to greedily consume your essence.
The Heart Itself spontaneously manifests in your current position. You are killed when this ability is used – crushed under the weight of impossible mathematics and ruinous vectors. Lines and angles no longer fully meet at the seams as raw nuclear chaos unfolds within you. After a few seconds of utter nightmare, the manifestation collapses, lapsing back into its natural state.