![[Deadwalker  Core Traits.png]]

[[Tags#EXTREME RANGE|EXTREME RANGE tag]]

[[Tags#RELOAD|RELOAD tag]]

[[Tags#TIRING|TIRING tag]]

[[Tags#POTENT|POTENT tag]]

[[Tags#EXPENSIVE|EXPENSIVE tag]]