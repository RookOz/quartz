![[Junk Mage  Core Traits.png]]

[[Tags#RANGED|RANGED tag]]

[[Tags#LOUD|LOUD tag]]

[[Tags#ONE-SHOT|ONE-SHOT tag]]

[[Tags#BRUTAL|BRUTAL tag]]

[[Tags#BLOODBOUND|BLOODBOUND tag]]

[[Tags#DANGEROUS|DANGEROUS tag]]

[[Tags#SPREAD|SPREAD tag]]

[[Tags#POINT-BLANK|POINT-BLANK tag]]