# RAVENING KNOWLEDGE
You crave the touch of what others call “madness”. The glimpses of truth that ravage your frail, mortal mind give you unimaginable power. When your Mind stress is 4 or higher, roll with mastery when you attempt to cast a spell.

# SACRIFICE
You are willing to sacrifice anything for another hit. Before you cast a spell from this class, you can opt to destroy a resource with the Occult domain. Roll the resource’s dice; the amount rolled is added to your Protection value against any stress incurred as a result of casting the spell.