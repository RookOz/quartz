# FINAL FORM
You reach down deep within yourself, inside the singing of your blood, and unearth your purest state: a nightblack being of wrath and ruin. Your true form was but a mere shadow of this.
You have complete control over the landmark you are currently occupying (or the nearby area, if you’re on a delve) and you are omniscient and omnipresent within its borders. You alone chooses who lives and dies inside.
At the end of the situation after you activate this power, the area you are in is stained forever with your essence. It counts as one tier deeper than it was before and changes to become appropriately strange. You live on as an echo, a mark on the place; it becomes part of you, and you part of it.

# PERFECT RESURRECTION
The communion between flesh and fracture, between the mortal and the undying, becomes near-perfect. You can make a perfect copy of someone who has died, but only once. The copy is absolutely the same as the original, right down to the soul. The copy is so good, in fact, that the person can no longer permanently die.
If they sustain damage that would kill them, they appear dead, but in fact a new copy is pupating somewhere in the depths of the Heart. It will slide out wetly within a lunar month. They get no say in this, and there is no known way to turn it off short of destroying the Heart Itself.
Casting this spell takes an hour or so of ritual chanting and kills you.

# THE RED QUEEN
You ascend to dominance over the witches of Hallow. Following a long period of scheming or a single night of decisive action, you are now in charge of all the witches of Hallow. Such a force, when mobilised, is terrifying to behold: their true forms skitter and swarm across rooftops and in the shadows. Few can stand in their path and survive.
After a session or two, the realities of being the head witch set in – there is a surprising amount of admin to do, and other witches are always coming to you with requests for aid. Pretty soon you’re going to be interred in the Red Vaults beneath Hallow (as all the leaders of the witches are) to join the chorus of elders.