# CRUCIBLE
You bring the energy of the Heart inside yourself and transmute it into crimson power. At any time, roll a D6. If it’s equal to or under your current Echo stress, clear that much stress from Echo and roll with mastery on your next action. If it’s over your current Echo stress, add that much stress to Echo.

# TRUE FORM
Your skin skitters with barely-contained force: the heartsblood within you is waiting to remake you as a flickering, hungry zoetrope horror. Whenever you want to, or when you suffer Major fallout, you enter your true form – describe it. When in your true form, you roll with mastery on Hunt and Kill checks, but all other checks become Risky. At the end of the current situation, you revert to your humanoid form.