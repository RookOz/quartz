![[Witch  Core Traits.png]]

[[Tags#BLOODBOUND|BLOODBOUND tag]]

[[Tags#RANGED|RANGED tag]]

[[Tags#RELOAD|RELOAD tag]]