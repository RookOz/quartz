You betrayed the trust of your order. Due to negligence, cowardice or malice, you caused them great harm. Now, wracked with guilt, you have sworn to make amends by venturing deep into the Heart and performing acts in service of your order.

# Core Ability
NOT YET: Your willpower, fuelled with guilt, is legendary. Once per session, activate this ability to avoid suffering negative effects from Blood or Mind fallout for the remainder of the situation.

# Character creation questions
• What marks your order out from others like it?
• What evidence of your failings is visible in the City Beneath?
• Pick one of the other player characters; they were present at your betrayal. How were they involved?
• Pick one of the other player characters; you look up to them as an example of how to live one’s life. What inspired this?

# Items (Pick one)
1. Absolution chains (heavy)
2. Vellum scroll bearing a record of your crimes
3. Still-itching tattoo depicting your sins
4. The skull of someone you loved
5. Vial of ashes with a name on it
6. Masonry fragment from a destroyed statue
7. Book of handwritten, melodramatic poetry
8. Locket depicting a beautiful one-eyed drow
9. Ceremonial bronze Watchful Eye
10. Brand identifying you as one of the secretive knights of the Covenant of the Fallen Tower