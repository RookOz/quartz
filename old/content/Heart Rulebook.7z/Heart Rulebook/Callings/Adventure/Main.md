The City Above holds no more excitement for you. In the City Beneath, on the knife-edge between real and unreal, you can be who you really are.

# Core Ability
LEGENDARY: You strive to live up to the stories that they’ll tell of your exploits. When you gain a minor advance, refresh D6. When you gain a major advance, refresh D8.

# Character creation questions
• What drove you out of the City Above?
• You and another player character barely escaped from a dangerous situation recently. Who was it and what happened?
• Recently, you and another character returned from a delve with an item for a wealthy patron. They wouldn’t give it up – why, and what was it?
• What’s the most dangerous beast or individual you’ve heard tell of, and why haven’t you defeated them yet?

# Items (Pick one)
1. Pulp novel loosely based on your exploits
2. Mouth organ
3. Spidersilk scarf in a dashing colour
4. Inaccurate map of the Heart you bought off some guy in Derelictus
5. Copy of “RAVENOUS SHE-WITCHES OF HALLOW”, a best-selling sensationalist book
6. Paper and sketching charcoal
7. Fake “Abomination-hunting” license
8. Unpunched Vermissian ticket used as a good luck charm
9. Letters from your mum asking when you’re going to come home
10. Expensive kohl eyeliner and pocket-mirror