When you sleep, you dream of the Heart. You’re half-mad with glimpses of knowledge; mad enough to go ever deeper into the undercity, looking for revelations.

# Core Ability
IN THE BLOOD: You move through the Heart as if blessed. +1 Echo Protection. Once per situation, when you take stress to any resistance other than Echo, allocate it to Echo.

# Character creation questions
• Which three images, symbols, people or creatures do you repeatedly see when you dream?
• What signs do you look for to recognise where the Heart is strongest?
• You recently witnessed an unearthly sight with another player character. Who was it, what happened and how did they react?
• Your connection to the Heart has touched you in some way. How does that manifest?

# Items (Pick one)
1. Ink-blotted dream journal with maps of places you saw when you were asleep
2. Bag of bitter stimulant pastilles 
3. Steel syringe and opiate powder
4. The word “THEOLOSIAN” growing over your upper chest
5. Barely-viable homonculus you shamefully coughed up or excised (name it)
6. Twenty sketches of the man you’re convinced you’re going to meet down here, all made by different artists
7. Signed copy of BEYOND THE EDGE OF MADNESS: A Year In The Heart by Gris Hanneman
8. Mandala made from hollow crow bones
9. Mad, impressionist votive image of a Witch
10. Greenish candles that help you sleep a dreamless sleep (sometimes)