# Minor Beats 
□ Following a long ritual, name The Heart. Only refer to it by this name from now on.

□ Take Minor Echo fallout.

□ See something from your dreams in the real world.

□ Consume something of the Heart (eat the flesh of a heartsblood beast, etc).

□ Be rendered helpless in the Heart for an hour or more.

□ Perform a rite at a place of power (Tier 2 or deeper).

□ Damage or sabotage a haven, letting the Heart in.

□ Sacrifice something you love to the Heart.

□ Allow something dangerous of the Heart to live when you could have killed it.

□ Let your curiosity lead you into danger.

□ Undergo a trance-like vision that lasts for hours.

□ Communicate with something of the Heart.

□ Witness an emissary of the Heart Itself.

□ Experience a pulse – the changing of the Heart from one state to another – first-hand.

□ Receive insight from a witch, a heartsblooded person or something stranger still.

□ Gain information on why you have been chosen by the Heart.

□ Receive a strange surgical implant or heartsblood transfusion.

□ Build a shrine to the Heart somewhere important.

□ Terrify or intrigue an NPC with your obsession.

□ Perform an act of service to an NPC witch.

□ Shelter someone touched by the Heart from persecution.

□ Find a heart-touched sapling on a delve and bring it back to a haven for plantingץ

□ Convince the party to collect Cursed resources on a delve, adding D6 to the delve’s resistance.

# Major Beats 
□ Take Major Echo fallout.

□ Perform a rite at a place of power (Tier 3 or deeper).

□ Sacrifice someone important to the Heart.

□ Establish a bond with a hearts-blood beast (Tier 2 or deeper).

□ Show the truth of the Heart’s majesty to an outsider (Tier 2 or deeper).

□ Meet and learn from an emissary of the Heart.

□ Destroy a haven, returning the land to the Heart.

□ One of your bonds takes Critical fallout thanks to your actions.

□ Deliver a crucial message on behalf of the Heart.

□ Visit three Vermissian Stations.

# Zenith Beats 
□ Become one with the Heart, and bind your essence to it.

□ Break the hold that the Heart has over you, ripping it from your body and spirit.