You don’t want to be down here, but you don’t have any choice. You’re a prisoner, an initiate to a cult or someone’s blackmailing you.

# Core Ability
COLLATERAL: You have a knack for getting behind someone else when things kick off. Once per session, allocate stress to the nearest friendly target (PC or NPC) instead of marking it yourself.

# Character creation questions
• Who, or what, are your masters?
• What do your masters want?
• How are your masters maintaining power over you?
• How do your masters contact you?
• Choose another player character. They have history with your masters too. What’s their relationship?

# Items (Pick one)
1. Daguerreotype of your son
2. Moonsilver collar
3. Signed contract detailing your “employment”
4. Matchbook from The Manticore, an up-Spire casino
5. Subjugation sliver implanted in your neck
6. Guild brand on your upper arm
7. Deed to an apartment in Ivory Row up-Spire
8. Mark on your chest where your soul used to be, before you sold it
9. Your master’s sigil, wrought from iron
10. Codebook showing you how and where to make your reports